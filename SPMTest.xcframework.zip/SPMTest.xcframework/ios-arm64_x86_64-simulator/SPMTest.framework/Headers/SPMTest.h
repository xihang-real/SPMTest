//
//  SPMTest.h
//  SPMTest
//
//  Created by zego on 2023/1/30.
//

#import <Foundation/Foundation.h>

//! Project version number for SPMTest.
FOUNDATION_EXPORT double SPMTestVersionNumber;

//! Project version string for SPMTest.
FOUNDATION_EXPORT const unsigned char SPMTestVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SPMTest/PublicHeader.h>


